<?php
/**
 * Single page settings page
 *
 * @package CartFlows
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div id="wcf-settings-app" class="wcf-settings-app">
</div>
